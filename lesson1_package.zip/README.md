# Lesson 1: SQL Server va SSMS Kirish

## 📌 Eslatmalar
- Topshiriqlar **SQL Server** yordamida bajarilishi kerak.
- **Katta-kichik harflar** farq qilmaydi.
- **Alias nomlari** bahoga ta’sir qilmaydi.
- **Natija to‘g‘ri chiqishi** asosida baho beriladi.
- Har bir topshiriq uchun **bitta to‘g‘ri yechim** yetarli.

---

## 🟢 Oson (Easy)

### 1. Tushunchalar ta’rifi:
- **Ma’lumot (data)** – Kompyuterda yoki boshqa qurilmada saqlanadigan raqam, matn, rasm, audio va video ko‘rinishidagi faktlar va qiymatlar to‘plami.
- **Ma’lumotlar bazasi (database)** – Ma’lumotlarni tartibli va tizimli saqlash hamda boshqarish uchun mo‘ljallangan struktura.
- **Relatsion ma’lumotlar bazasi (relational database)** – Jadval ko‘rinishida saqlanadigan, ular orasida bog‘lanishlar (relationship) mavjud bo‘lgan ma’lumotlar bazasi.
- **Jadval (table)** – Ma’lumotlar bazasidagi qatorlar (row) va ustunlardan (column) iborat tuzilma.

### 2. SQL Server’ning 5 ta asosiy xususiyati:
1. Katta hajmdagi ma’lumotlar bilan ishlash imkoniyati.  
2. Yuqori darajadagi xavfsizlik (security).  
3. Yedeklash (backup) va tiklash (restore) funksiyalari.  
4. Tarmoq orqali bir nechta foydalanuvchilar bilan ishlash imkoniyati.  
5. Murakkab so‘rovlarni tez bajarish optimizatsiyasi.

### 3. SQL Server avtorizatsiya rejimlari:
- **Windows Authentication** – Windows tizimidagi foydalanuvchi login va parolini ishlatadi.
- **SQL Server Authentication** – SQL Server ichida yaratilgan foydalanuvchi nomi va parolini ishlatadi.

---

## 🟡 O‘rta (Medium)

### 4. Yangi ma’lumotlar bazasi yaratish:
```sql
CREATE DATABASE SchoolDB;
```

### 5. Students jadvalini yaratish:
```sql
CREATE TABLE Students (
    StudentID INT PRIMARY KEY,
    Name VARCHAR(50),
    Age INT
);
```

### 6. SQL Server, SSMS va SQL farqlari:
- **SQL Server** – Microsoft ishlab chiqqan ma’lumotlar bazasi boshqaruv tizimi (DBMS).
- **SSMS (SQL Server Management Studio)** – SQL Server bilan ishlash uchun qulay grafik interfeysli dastur.
- **SQL (Structured Query Language)** – Ma’lumotlar bazasi bilan muloqot qilish uchun ishlatiladigan so‘rov tili.

---

## 🔴 Qiyin (Hard)

### 7. SQL buyruqlari turlari:

| Buyruq turi | To‘liq nomi | Maqsadi | Misol |
|-------------|-------------|---------|-------|
| **DQL** | Data Query Language | Ma’lumotlarni so‘rash | `SELECT * FROM Students;` |
| **DML** | Data Manipulation Language | Ma’lumotlarni o‘zgartirish | `INSERT`, `UPDATE`, `DELETE` |
| **DDL** | Data Definition Language | Ma’lumotlar bazasi strukturasini boshqarish | `CREATE TABLE`, `ALTER TABLE`, `DROP TABLE` |
| **DCL** | Data Control Language | Foydalanuvchi huquqlarini boshqarish | `GRANT`, `REVOKE` |
| **TCL** | Transaction Control Language | Tranzaksiyalarni boshqarish | `COMMIT`, `ROLLBACK` |

---

### 8. Students jadvaliga 3 ta yozuv qo‘shish:
```sql
INSERT INTO Students (StudentID, Name, Age) VALUES
(1, 'Ali', 20),
(2, 'Laylo', 22),
(3, 'Javlon', 19);
```

---

### 9. AdventureWorksDW2022 ma’lumotlar bazasini tiklash bosqichlari:
1. GitHub’dan `AdventureWorksDW2022.bak` faylini yuklab oling.  
   [Yuklab olish havolasi](https://github.com/Microsoft/sql-server-samples/releases/download/adventureworks/AdventureWorksDW2022.bak)  
2. Faylni SQL Server yedeklar papkasiga joylashtiring (masalan: `C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\Backup\`).  
3. SSMS’ni oching va serverga ulang.  
4. **Databases** ustida o‘ng tugma → **Restore Database**.  
5. **Device** bo‘limida **.bak** faylni tanlang.  
6. **OK** tugmasini bosing, tiklash jarayoni tugagach, ma’lumotlar bazasi ishlashga tayyor bo‘ladi.
